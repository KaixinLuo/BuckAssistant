window.onload = function() {
    var virtual = new VirtualAdvisor();
    virtual.init();
};
var VirtualAdvisor = function () {
    this.socket = null;
};
VirtualAdvisor.prototype = {
    init: function() {
        var that = this;
        this.socket = io.connect();
        this.socket.on('connect', function() {
            document.getElementById('messageInput').focus();
        });
        this.socket.on('error', function (err) {
            document.getElementById('info').textContent = '!fail to connect :(';
        });
        this.socket.on('newMsg', function(msg) {
            that._displayNewMsg(msg);
        });
        document.getElementById('sendBtn').addEventListener('click', function() {
            var messageInput = document.getElementById('messageInput'),
                msg = messageInput.value;
            messageInput.value = '';
            messageInput.focus();
            if (msg.trim().length != 0) {
                that.socket.emit('postMsg', msg);
                that._displayNewMsg(msg);
                return;
            };
        }, false);
        document.getElementById('messageInput').addEventListener('keyup', function(e) {
            var messageInput = document.getElementById('messageInput'),
                msg = messageInput.value;
            if (e.keyCode == 13 && msg.trim().length != 0) {
                messageInput.value = '';
                that.socket.emit('postMsg', msg);
                that._displayNewMsg(msg);
            };
        }, false);
        document.getElementById('clearBtn').addEventListener('click', function() {
            document.getElementById('historyMsg').innerHTML = '';
        }, false);
    },
    _displayNewMsg: function(msg) {
        var container = document.getElementById('historyMsg'),
            msgToDisplay = document.createElement('p'),
            date = new Date().toTimeString().substr(0, 8);
        msgToDisplay.style.color = '#000';
        msgToDisplay.innerHTML = 'me'+'<span class="timespan">(' + date + '): </span> <br/>' + msg;
        container.appendChild(msgToDisplay);
        container.scrollTop = container.scrollHeight;
    }
};
