import requests
import re
import os

r = requests.get("https://coe-portal.cse.ohio-state.edu/pdf-exports/CSE/")

nameList=re.findall(r"CSE-[1-9][1-9][1-9][1-9]\.pdf",r.text,flags=0)
print (nameList)

for pdf_name in nameList:
    path = "~/syllabuses"
    os.mkdir(path)
    with open("./data/General_"+pdf_name,'wb') as f:
        tempR = requests.get("https://coe-portal.cse.ohio-state.edu/pdf-exports/CSE/" + pdf_name)
        f.write(tempR.content)
        f.close()


